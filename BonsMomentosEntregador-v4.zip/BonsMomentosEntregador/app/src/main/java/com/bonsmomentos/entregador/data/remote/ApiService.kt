package com.bonsmomentos.entregador.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/** API do Supabase: Auth (login) + funções do banco criadas em supabase_setup.sql. */
interface ApiService {
    @POST("auth/v1/token?grant_type=password")
    suspend fun entrar(@Body body: PasswordGrant): AuthResponse

    @POST("auth/v1/token?grant_type=refresh_token")
    suspend fun renovar(@Body body: RefreshGrant): AuthResponse

    @GET("rest/v1/rpc/meu_perfil")
    suspend fun meuPerfil(): List<PerfilDto>

    @GET("rest/v1/rpc/meus_pedidos")
    suspend fun meusPedidos(): List<PedidoDto>

    @POST("rest/v1/rpc/concluir_pedido")
    suspend fun concluirPedido(@Body body: ConcluirRequest): Response<Unit>
}
