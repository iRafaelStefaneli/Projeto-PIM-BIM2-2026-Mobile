package com.bonsmomentos.entregador.data.remote

import com.bonsmomentos.entregador.data.local.PedidoEntity
import com.bonsmomentos.entregador.data.local.StatusPedido

// ----- Supabase Auth (os nomes em snake_case são os do JSON do Supabase) -----
data class PasswordGrant(val email: String, val password: String)
data class RefreshGrant(val refresh_token: String)
data class AuthResponse(
    val access_token: String = "",
    val refresh_token: String? = null,
    val expires_in: Long = 0
)

// ----- Funções do banco (supabase_setup.sql) -----
data class PerfilDto(val id: Long = 0, val nome: String? = null)
data class ConcluirRequest(val p_id: Long)

/** Campos nulos/ausentes no JSON viram texto vazio. */
data class PedidoDto(
    val id: Long = 0,
    val produto: String? = null,
    val pagamento: String? = null,
    val cep: String? = null,
    val endereco: String? = null,
    val status: String? = null
) {
    fun paraEntity() = PedidoEntity(
        id = id,
        produto = produto.orEmpty(),
        pagamento = pagamento.orEmpty(),
        cep = cep.orEmpty(),
        endereco = endereco.orEmpty(),
        // "Em rota" -> EM_ROTA, "Entregue" -> ENTREGUE
        status = status?.trim()?.uppercase()?.replace(' ', '_') ?: StatusPedido.PENDENTE,
        syncPendente = false,
        atualizadoEm = System.currentTimeMillis()
    )
}
