package com.bonsmomentos.entregador.data.remote

import com.bonsmomentos.entregador.BuildConfig
import com.bonsmomentos.entregador.data.SessionManager
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object ApiClient {

    fun create(session: SessionManager): ApiService {
        // Cliente simples (sem token) só para renovar a sessão
        val semToken = baseClient()
            .addInterceptor(chaveInterceptor(session, comToken = false))
            .build()
        val authApi = retrofit(semToken)

        val principal = baseClient()
            .addInterceptor(chaveInterceptor(session, comToken = true))
            .authenticator(RenovaToken(session, authApi))
            .build()
        return retrofit(principal)
    }

    private fun baseClient(): OkHttpClient.Builder {
        val log = HttpLoggingInterceptor().apply {
            redactHeader("Authorization")
            redactHeader("apikey")
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC
            else HttpLoggingInterceptor.Level.NONE
        }
        return OkHttpClient.Builder()
            .addInterceptor(log)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
    }

    private fun retrofit(client: OkHttpClient): ApiService =
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)

    /** Toda chamada leva a chave pública; as do banco levam também o token do entregador. */
    private fun chaveInterceptor(session: SessionManager, comToken: Boolean) = Interceptor { chain ->
        val req = chain.request().newBuilder().header("apikey", BuildConfig.SUPABASE_KEY)
        val token = session.token()
        if (comToken && token != null && !chain.request().url.encodedPath.startsWith("/auth/")) {
            req.header("Authorization", "Bearer $token")
        }
        chain.proceed(req.build())
    }

    /** Se o servidor responder 401 (token vencido), renova com o refresh token e repete a chamada. */
    private class RenovaToken(
        private val session: SessionManager,
        private val authApi: ApiService
    ) : Authenticator {
        override fun authenticate(route: Route?, response: Response): Request? {
            if (response.request.url.encodedPath.startsWith("/auth/")) return null
            if (response.priorResponse != null) return null   // já tentou renovar uma vez
            return synchronized(this) { renovar(response) }
        }

        private fun renovar(response: Response): Request? {
            val enviado = response.request.header("Authorization")?.removePrefix("Bearer ")
            val atual = session.token()
            if (atual != null && atual != enviado) {          // outra chamada já renovou
                return response.request.newBuilder()
                    .header("Authorization", "Bearer $atual").build()
            }
            val refresh = session.refreshToken() ?: return null
            val novo = try {
                runBlocking { authApi.renovar(RefreshGrant(refresh)) }
            } catch (e: Exception) {
                return null
            }
            if (novo.access_token.isEmpty()) return null
            session.atualizarTokens(novo.access_token, novo.refresh_token ?: refresh)
            return response.request.newBuilder()
                .header("Authorization", "Bearer ${novo.access_token}").build()
        }
    }
}
