package com.bonsmomentos.entregador.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EntregaDao {

    @Query("SELECT * FROM entregas ORDER BY (status = 'ENTREGUE'), id")
    fun observarTodas(): Flow<List<EntregaEntity>>

    @Query("SELECT * FROM entregas WHERE syncPendente = 1")
    suspend fun pendentes(): List<EntregaEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(lista: List<EntregaEntity>)

    @Query("UPDATE entregas SET status = :status, syncPendente = 1, atualizadoEm = :ts WHERE id = :id")
    suspend fun atualizarStatusLocal(id: Long, status: String, ts: Long)

    /** Só limpa a flag se o registro não mudou desde o envio (evita perder edição concorrente). */
    @Query("UPDATE entregas SET syncPendente = 0 WHERE id = :id AND atualizadoEm = :ts")
    suspend fun marcarSincronizada(id: Long, ts: Long)

    @Query("DELETE FROM entregas WHERE syncPendente = 0 AND id NOT IN (:idsRemotos)")
    suspend fun removerAusentes(idsRemotos: List<Long>)

    @Query("DELETE FROM entregas")
    suspend fun limparTudo()
}
