package com.bonsmomentos.entregador.ui

import android.app.Application
import android.util.Patterns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.bonsmomentos.entregador.App
import kotlinx.coroutines.launch

sealed class LoginState {
    object Ocioso : LoginState()
    object Carregando : LoginState()
    object Sucesso : LoginState()
    data class Erro(val mensagem: String) : LoginState()
}

class LoginViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = (app as App).repository
    val estado = MutableLiveData<LoginState>(LoginState.Ocioso)

    fun entrar(email: String, senha: String) {
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            estado.value = LoginState.Erro("Informe um email válido"); return
        }
        if (senha.isEmpty()) {
            estado.value = LoginState.Erro("Informe a senha"); return
        }
        estado.value = LoginState.Carregando
        viewModelScope.launch {
            repo.login(email.trim(), senha).fold(
                onSuccess = { estado.value = LoginState.Sucesso },
                onFailure = { estado.value = LoginState.Erro(it.message ?: "Falha no login") }
            )
        }
    }
}
