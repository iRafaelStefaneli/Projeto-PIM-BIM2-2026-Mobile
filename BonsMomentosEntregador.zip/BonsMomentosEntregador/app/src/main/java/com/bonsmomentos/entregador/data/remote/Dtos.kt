package com.bonsmomentos.entregador.data.remote

import com.bonsmomentos.entregador.data.local.EntregaEntity

data class LoginRequest(val email: String, val senha: String)
data class LoginResponse(val token: String, val id: Long, val nome: String)

data class EntregaDto(
    val id: Long,
    val cliente: String,
    val endereco: String,
    val status: String
) {
    fun paraEntity() = EntregaEntity(
        id = id, cliente = cliente, endereco = endereco, status = status,
        syncPendente = false, atualizadoEm = System.currentTimeMillis()
    )
}

data class StatusRequest(val status: String, val atualizadoEm: Long)
