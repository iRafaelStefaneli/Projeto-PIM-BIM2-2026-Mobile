package com.bonsmomentos.entregador.data

import com.bonsmomentos.entregador.data.local.EntregaDao
import com.bonsmomentos.entregador.data.local.StatusEntrega
import com.bonsmomentos.entregador.data.remote.ApiService
import com.bonsmomentos.entregador.data.remote.LoginRequest
import com.bonsmomentos.entregador.data.remote.StatusRequest
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import retrofit2.HttpException
import java.io.IOException

enum class SyncResult { SUCESSO, FALHA_REDE, NAO_AUTORIZADO }

/**
 * Fonte única da verdade = banco local (Room).
 * A UI só lê do banco; o servidor é atualizado/consultado pela sincronização.
 */
class Repository(
    private val api: ApiService,
    private val dao: EntregaDao,
    private val session: SessionManager
) {
    val entregas = dao.observarTodas()
    private val mutex = Mutex()

    suspend fun login(email: String, senha: String): Result<Unit> = try {
        val r = api.login(LoginRequest(email, senha))
        session.salvar(r.token, r.id, r.nome)
        Result.success(Unit)
    } catch (e: HttpException) {
        Result.failure(
            Exception(
                if (e.code() == 401 || e.code() == 403) "Email ou senha inválidos"
                else "Erro no servidor (${e.code()})"
            )
        )
    } catch (e: IOException) {
        Result.failure(Exception("Sem conexão com o servidor"))
    }

    /** Grava localmente na hora (funciona offline) e marca como pendente de envio. */
    suspend fun marcarEntregue(id: Long) =
        dao.atualizarStatusLocal(id, StatusEntrega.ENTREGUE, System.currentTimeMillis())

    /** 1) envia pendências  2) baixa lista do servidor  3) mescla sem sobrescrever pendências. */
    suspend fun sincronizar(): SyncResult = mutex.withLock {
        try {
            for (e in dao.pendentes()) {
                val resp = api.atualizarStatus(e.id, StatusRequest(e.status, e.atualizadoEm))
                if (resp.isSuccessful) dao.marcarSincronizada(e.id, e.atualizadoEm)
                else if (resp.code() == 401) return@withLock SyncResult.NAO_AUTORIZADO
            }

            val remotas = api.entregas()
            val aindaPendentes = dao.pendentes().map { it.id }.toSet()
            dao.upsertAll(remotas.filter { it.id !in aindaPendentes }.map { it.paraEntity() })
            dao.removerAusentes(remotas.map { it.id })

            session.registrarSync(System.currentTimeMillis())
            SyncResult.SUCESSO
        } catch (e: HttpException) {
            if (e.code() == 401) SyncResult.NAO_AUTORIZADO else SyncResult.FALHA_REDE
        } catch (e: IOException) {
            SyncResult.FALHA_REDE
        }
    }

    suspend fun logout() {
        session.limpar()
        dao.limparTudo()
    }
}
