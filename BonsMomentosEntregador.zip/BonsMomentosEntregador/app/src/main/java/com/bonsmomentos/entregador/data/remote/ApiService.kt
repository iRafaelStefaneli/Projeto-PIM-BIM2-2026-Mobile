package com.bonsmomentos.entregador.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path

/** Contrato esperado do backend — ajuste os caminhos/campos conforme a sua API. */
interface ApiService {
    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): LoginResponse

    @GET("entregas")
    suspend fun entregas(): List<EntregaDto>

    @PATCH("entregas/{id}/status")
    suspend fun atualizarStatus(@Path("id") id: Long, @Body body: StatusRequest): Response<Unit>
}
