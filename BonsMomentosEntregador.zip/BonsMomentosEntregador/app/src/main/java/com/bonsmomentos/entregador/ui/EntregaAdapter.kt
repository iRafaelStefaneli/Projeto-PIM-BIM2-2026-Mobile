package com.bonsmomentos.entregador.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bonsmomentos.entregador.data.local.EntregaEntity
import com.bonsmomentos.entregador.data.local.StatusEntrega
import com.bonsmomentos.entregador.databinding.ItemEntregaBinding

class EntregaAdapter(
    private val aoConcluir: (EntregaEntity) -> Unit
) : ListAdapter<EntregaEntity, EntregaAdapter.VH>(Diff) {

    inner class VH(val b: ItemEntregaBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemEntregaBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = getItem(position)
        with(holder.b) {
            tvCliente.text = e.cliente
            tvEndereco.text = e.endereco
            val rotulo = when (e.status) {
                StatusEntrega.ENTREGUE -> "Entregue"
                StatusEntrega.EM_ROTA -> "Em rota"
                else -> "Pendente"
            }
            tvStatus.text = if (e.syncPendente) "$rotulo • aguardando sincronização" else rotulo
            btnConcluir.visibility = if (e.status == StatusEntrega.ENTREGUE) View.GONE else View.VISIBLE
            btnConcluir.setOnClickListener { aoConcluir(e) }
        }
    }

    private object Diff : DiffUtil.ItemCallback<EntregaEntity>() {
        override fun areItemsTheSame(a: EntregaEntity, b: EntregaEntity) = a.id == b.id
        override fun areContentsTheSame(a: EntregaEntity, b: EntregaEntity) = a == b
    }
}
