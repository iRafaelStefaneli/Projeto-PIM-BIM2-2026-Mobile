package com.bonsmomentos.entregador.data.remote

import com.bonsmomentos.entregador.data.local.PedidoEntity
import com.bonsmomentos.entregador.data.local.StatusPedido

data class LoginRequest(val email: String, val senha: String)
data class LoginResponse(val token: String, val id: Long, val nome: String)

/** Campos nulos/ausentes no JSON viram texto vazio (a API ainda pode mudar). */
data class PedidoDto(
    val id: Long = 0,
    val produto: String? = null,
    val pagamento: String? = null,
    val cep: String? = null,
    val endereco: String? = null,
    val status: String? = null
) {
    fun paraEntity() = PedidoEntity(
        id = id,
        produto = produto.orEmpty(),
        pagamento = pagamento.orEmpty(),
        cep = cep.orEmpty(),
        endereco = endereco.orEmpty(),
        status = status?.trim()?.uppercase() ?: StatusPedido.PENDENTE,
        syncPendente = false,
        atualizadoEm = System.currentTimeMillis()
    )
}

data class StatusRequest(val status: String, val atualizadoEm: Long)
