package com.bonsmomentos.entregador.data.remote

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * Contrato PROVISÓRIO do backend — ajustar quando a API real estiver pronta.
 * (caminhos, nomes dos campos do JSON e formato do status)
 */
interface ApiService {
    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): LoginResponse

    @GET("pedidos")
    suspend fun pedidos(): List<PedidoDto>

    @PATCH("pedidos/{id}/status")
    suspend fun atualizarStatus(@Path("id") id: Long, @Body body: StatusRequest): Response<Unit>
}
