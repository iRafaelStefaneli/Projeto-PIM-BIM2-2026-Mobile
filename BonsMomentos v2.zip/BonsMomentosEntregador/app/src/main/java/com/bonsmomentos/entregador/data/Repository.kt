package com.bonsmomentos.entregador.data

import com.bonsmomentos.entregador.BuildConfig
import com.bonsmomentos.entregador.data.local.PedidoDao
import com.bonsmomentos.entregador.data.local.PedidoEntity
import com.bonsmomentos.entregador.data.local.StatusPedido
import com.bonsmomentos.entregador.data.remote.ApiService
import com.bonsmomentos.entregador.data.remote.LoginRequest
import com.bonsmomentos.entregador.data.remote.StatusRequest
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import retrofit2.HttpException
import java.io.IOException

enum class SyncResult { SUCESSO, FALHA_REDE, NAO_AUTORIZADO }

/**
 * Fonte única da verdade = banco local (Room).
 * A UI só lê do banco; o servidor é atualizado/consultado pela sincronização.
 */
class Repository(
    private val api: ApiService,
    private val dao: PedidoDao,
    private val session: SessionManager
) {
    val pedidos = dao.observarDisponiveis()
    val qtdPendentes = dao.observarQtdPendentes()
    private val mutex = Mutex()

    suspend fun login(email: String, senha: String): Result<Unit> {
        if (BuildConfig.MODO_DEMO) {
            session.salvar("token-demo", 0L, "Entregador Demo")
            return Result.success(Unit)
        }
        return try {
            val r = api.login(LoginRequest(email, senha))
            session.salvar(r.token, r.id, r.nome)
            Result.success(Unit)
        } catch (e: HttpException) {
            Result.failure(
                Exception(
                    if (e.code() == 401 || e.code() == 403) "Email ou senha inválidos"
                    else "Erro no servidor (${e.code()})"
                )
            )
        } catch (e: IOException) {
            Result.failure(Exception("Sem conexão com o servidor"))
        }
    }

    /** Grava localmente na hora (funciona offline) e marca como pendente de envio. */
    suspend fun marcarEntregue(id: Long) =
        dao.atualizarStatusLocal(id, StatusPedido.ENTREGUE, System.currentTimeMillis())

    /** 1) envia pendências  2) baixa lista do servidor  3) mescla sem sobrescrever pendências. */
    suspend fun sincronizar(): SyncResult = mutex.withLock {
        if (BuildConfig.MODO_DEMO) return@withLock sincronizarDemo()
        try {
            for (e in dao.pendentes()) {
                val resp = api.atualizarStatus(e.id, StatusRequest(e.status, e.atualizadoEm))
                if (resp.isSuccessful) dao.marcarSincronizada(e.id, e.atualizadoEm)
                else if (resp.code() == 401) return@withLock SyncResult.NAO_AUTORIZADO
            }

            val remotos = api.pedidos()
            val aindaPendentes = dao.pendentes().map { it.id }.toSet()
            dao.upsertAll(remotos.filter { it.id !in aindaPendentes }.map { it.paraEntity() })
            dao.removerAusentes(remotos.map { it.id })

            session.registrarSync(System.currentTimeMillis())
            SyncResult.SUCESSO
        } catch (e: HttpException) {
            if (e.code() == 401) SyncResult.NAO_AUTORIZADO else SyncResult.FALHA_REDE
        } catch (e: IOException) {
            SyncResult.FALHA_REDE
        }
    }

    /** MODO DEMONSTRAÇÃO: sem servidor. Cria pedidos de exemplo uma única vez por login. */
    private suspend fun sincronizarDemo(): SyncResult {
        for (e in dao.pendentes()) dao.marcarSincronizada(e.id, e.atualizadoEm)
        if (dao.contar() == 0) dao.upsertAll(pedidosDemo())
        session.registrarSync(System.currentTimeMillis())
        return SyncResult.SUCESSO
    }

    private fun pedidosDemo() = listOf(
        PedidoEntity(1, "Bolo de Chocolate", "PIX", "01001-000",
            "Rua Santos Domingos, N° 219 - Centro, São Paulo", StatusPedido.PENDENTE),
        PedidoEntity(2, "Torta de Morango", "Dinheiro", "04567-010",
            "Av. Exemplo, N° 111 - Vila Nova, São Paulo", StatusPedido.PENDENTE),
        PedidoEntity(3, "Caixa de Brigadeiros (12 un.)", "Cartão", "02020-020",
            "Rua das Flores, N° 45 - Jardim Bonito, São Paulo", StatusPedido.PENDENTE)
    )

    suspend fun logout() {
        session.limpar()
        dao.limparTudo()
    }
}
